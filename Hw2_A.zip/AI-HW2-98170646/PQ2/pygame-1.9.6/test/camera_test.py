import unittest
import math

import pygame
from pygame.compat import long_


class CameraModuleTest(unittest.TestCase):
    pass
